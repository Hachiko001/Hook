#pragma once
#include <Windows.h>

HWND hWnd;
HHOOK hMyHook;
HINSTANCE hInstance;
